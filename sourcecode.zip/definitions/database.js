// Database initialization
require('sqlagent/pg').init(CONFIG('database'));